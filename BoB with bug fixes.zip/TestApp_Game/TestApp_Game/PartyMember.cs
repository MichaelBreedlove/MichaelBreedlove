﻿using System.Collections.Generic;

namespace GameSpace
{
    public class PartyMember : Player //Party Members are an offshoot of the player class, since party members can faint and be revived, but if the player faints, it's game over.
    {
        public PartyMember(string GivenName, int BaseMaxHP, int BaseSpeed, int str, int def, int luck, int intel) : base(GivenName, BaseMaxHP, BaseSpeed, str, def, luck, intel) { }
    }
}
