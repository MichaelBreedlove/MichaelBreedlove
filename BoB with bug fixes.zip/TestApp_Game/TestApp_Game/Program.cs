﻿using System;

namespace GameSpace
{
    class Program
    {
        static void Main(string[] args)
        {
            new Game("Richard McConnell", "Boss of Bosses", 180, 50, ConsoleColor.White);
        }
    }
}