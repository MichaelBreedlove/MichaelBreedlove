﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameSpace
{
    public class Ability
    {
        public string AbilityName { get; private set; } = "Placeholder Name"; //Name
        public string AbilityDescription { get; private set; } = "Placeholder Description"; //Description
        public int AbilityIndex { get; private set; } = -1; //Some abilities apply special effects when used, based on their index.
        public int AbilityTargetMode { get; private set; } = 0; //1: Targets enemies. 2: Targets allies. Any other value: cannot target anything.
        public int AbilityDamage { get; private set; } = 0; //Damage
        public int AbilityHeal { get; private set; } = 0; //Healing

        public Ability(string Name, string Description, int Index, int TargetMode, int Damage = 0, int Heal = 0)
        {
            AbilityName = Name;
            AbilityDescription = Description;
            AbilityIndex = Index;
            AbilityTargetMode = TargetMode;
            AbilityDamage = Damage;
            AbilityHeal = Heal;
        }
    }
}
