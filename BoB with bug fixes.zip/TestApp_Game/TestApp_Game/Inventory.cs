﻿using System;
using System.Collections.Generic;
using static System.Console;

namespace GameSpace
{
    public class Inventory
    {
        public List<Item> Items = new List<Item>();
        public List<int> Quantity = new List<int>();

        public Inventory()
        {
            Items.Clear();
            Quantity.Clear();
        }

        public void ViewInventory(bool LetUse = true, bool Battle = false)
        {
            if (InventoryIsEmpty())
            {
                WriteLine("Your inventory is empty.");
            }
            else
            {
                if (!Battle)
                {
                    WriteLine("Your Inventory:");
                }
                else
                {
                    WriteLine(@"
");
                }

                for (int i = 0; i < Items.Count; i++)
                {
                    if (Quantity[i] > 0)
                    {
                        Write($"{i + 1}. ");
                        Write(Items[i].ItemName + " ");
                        ForegroundColor = ConsoleColor.Green;
                        WriteLine($"[x{Quantity[i]}]");
                        ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }

        public void GiveItem_Message(Item ItemObtained, int NumGiven, string FindMessage = "found", string punctuation = "!", ConsoleColor ItemColor = ConsoleColor.Green, bool DontActuallyGive = false, bool UseColon = true) //Prints a message telling the player they received an item, as well as its quantity. If DontActuallyGive is false, the player then receives the item.
        {
            string ItemName = ItemObtained.ItemName;

            if (NumGiven > 1)
            {
                ItemName = ItemName + $" (x{NumGiven})";
            }
            
            if (UseColon)
            {
                FindMessage = FindMessage + ":";
            }

            if (ItemColor == Game.getColor())
            {
                WriteLine($"You {FindMessage} {ItemName}{punctuation}");
            }
            else
            {
                Write($"You {FindMessage} ");
                ForegroundColor = ItemColor;
                Write($"{ItemName}");
                ForegroundColor = Game.getColor();
                Write($"{punctuation}");
                WriteLine("");
            }

            if (!DontActuallyGive)
            {
                GiveItem(ItemObtained, NumGiven);
            }

            ReadKey(true);
        }

        public void GiveItem(Item ItemObtained, int NumGiven) //Puts an item in the player's inventory, then adjusts the quantity of that item, without sending a message.
        {
            int i = ItemIsAlreadyInInventory(ItemObtained.ItemName);

            if (i == -1)
            {
                Items.Add(ItemObtained);
                Quantity.Add(NumGiven);
            }
            else
            {
                Quantity[i] += NumGiven;
            }
        }

        public int ItemIsAlreadyInInventory(string Name) //Returns the item's slot in the list if it is already in the player's inventory, otherwise it returns -1.
        {
            int i = 0;
            bool found = false;

            while (i < Items.Count && !found)
            {
                if (Items[i].ItemName == Name && Quantity[i] >= 1)
                {
                    found = true;
                }
                else
                {
                    i++;
                }
            }

            if (!found)
            {
                i = -1;
            }

            return i;
        }

        public bool NoBattleItems()
        {
            if (InventoryIsEmpty())
            {
                return true;
            }

            int i = 0;
            bool found = false;

            while (i < Items.Count && !found)
            {
                if (Items[i].CanUseInBattle && Quantity[i] >= 1)
                {
                    found = true;
                }

                i++;
            }

            return !found;
        }

        public bool InventoryIsEmpty()
        {
            return (Items.Count == 0);
        }

        public void RemoveItem(int Slot)
        {
            Quantity[Slot]--;

            if (Quantity[Slot] <= 0)
            {
                Items.RemoveAt(Slot);
                Quantity.RemoveAt(Slot);
            }
        }
    }
}
