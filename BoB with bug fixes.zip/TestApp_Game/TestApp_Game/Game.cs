﻿using System;
using System.Collections.Generic;
using static System.Console;
using static GameSpace.TextFunctions;
using static GameSpace.BattleSystem;
using static GameSpace.Inventory;

/*ABILITY INDEXES for future reference:
1. Mind Bender
2. Psychic Barrier
3. Taunt
4. Charge
5. Suspicious Syringe
6. Infection Injection
*/

namespace GameSpace
{
    public class Game
    {
        public static Player protag;
        public static bool InBattle = false;
        string DefName = "";
        TextFunctions ActiveMessage;

        CharacterTextFormat TextFormat_Narrator;
        CharacterTextFormat TextFormat_SecurityGuard;
        CharacterTextFormat TextFormat_YourBoss;

        static ConsoleColor defaultColor = ConsoleColor.White;

        public Game(string DefaultName, string WindowName, int WindowWidth, int WindowHeight, ConsoleColor defColor)
        {
            DefName = DefaultName;
            Title = WindowName;
            SetWindowSize(WindowWidth, WindowHeight);
            defaultColor = defColor;
            ForegroundColor = defaultColor;
            StartGame();
        }

        public void StartGame()
        {
            InitializeFormats();
            StartIntro();
        }

        internal static ConsoleColor getColor()
        {
            return defaultColor;
        }

        public void InitializeFormats() //Initialize our text formats that will be used for various purposes, such as specific players speaking, items being obtained, etc.
        {
            TextFormat_Narrator = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.White, false, false, true, true, false, true);
            TextFormat_SecurityGuard = new CharacterTextFormat("Security Guard", ConsoleColor.Yellow, ConsoleColor.White, true, false, true, true, true, true);
            TextFormat_YourBoss = new CharacterTextFormat("Your Boss", ConsoleColor.Red, ConsoleColor.White, true, false, true, true, true, true);
        }

        public void StartIntro() //Start the game's intro, which is where we'll get the player's name and introduce them to BoB's basic controls.
        {
            Game_PrintMessage("After about an hour of driving, you finally arrived at HQ. Your boss had requested to see you for an exam; judging by his tone over the phone, he was not happy.", TextFormat_Narrator);
            Game_PrintMessage("You enter the building, and are greeted by a security guard at the front desk.", TextFormat_Narrator);
            Game_PrintMessage("You. Give me your name. Or just say nothing [PRESS ENTER] if you don't care what I call you.", TextFormat_SecurityGuard, true);
            GetPlayerName();
        }

        void GetPlayerName() //Get the name of our player.
        {
            string input;

            input = ReadLine();
            bool DefaultUsed = false;
            string Name = DefName;

            if (input == "")
            {
                Game_PrintMessage($"Alright, then. I'll just call you {DefName}, since that's what your file says.", TextFormat_SecurityGuard);
                DefaultUsed = true;
            }
            else if (!DefaultUsed)
            {
                Name = ChoosePlayerName(input);
            }

            protag = new Player(Name, 30, 6, 12, 10, 6, 12);

            GiveAbilities();
            IntroText(DefaultUsed);
        }

        void GiveAbilities()
        {
            protag.Skills.Add(new Ability("Mind Bender", $@"{protag.Name} attempts to twist the target's mind, inflicting confusion for one turn while inflicting a small amount of damage in the process.
Damage and success rate increase with the user's intellect.", 1, 1, 6));
            protag.Skills.Add(new Ability("Psychic Barrier", $"{protag.Name} summons a psychic barrier to protect an ally, halving the next instance of damage they take.", 2, 2));
        }

        string ChoosePlayerName(string input) //If the player doesn't choose the default name, and doesn't skip the option to choose entirely, allow them to repeatedly choose a new name until they're satisfied with their choice.
        {
            bool nameChosen = false;

            for (int numEntries = 0; !nameChosen; numEntries++) //While the player has not chosen a name, allow them to infinitely enter new ones. Comes with a small easter egg where the narrator progressively becomes more annoyed the longer the user takes to choose a name.
            {
                if (numEntries < 3)
                {
                    Game_PrintMessage($"So you want to be called {input}, correct? [Y/N]", TextFormat_SecurityGuard, true);
                }
                else if (numEntries >= 3 && numEntries < 6)
                {
                    Game_PrintMessage($"Does {input} sound good? [Y/N]", TextFormat_SecurityGuard, true);
                }
                else if (numEntries >= 6)
                {
                    Game_PrintMessage($"Congratulations, {input}! By entering {numEntries} names, you have successfully ruined my day more than you already have. Are you finally happy with your name? [Y/N]", TextFormat_SecurityGuard, true);
                }

                string confirmation = ReadLine();

                if (ResponseIsConfirmation(confirmation))
                {
                    nameChosen = true;
                }
                else
                {
                    if (numEntries < 3)
                    {
                        Game_PrintMessage("Okay, then, give me a different name.", TextFormat_SecurityGuard, true);
                    }
                    else if (numEntries >= 3 && numEntries < 6)
                    {
                        Game_PrintMessage("Yeah, I get it, choosing a name can be difficult sometimes. What should I call you?", TextFormat_SecurityGuard, true);
                    }
                    else if (numEntries >= 6)
                    {
                        Game_PrintMessage("It's not funny anymore, quit wasting my time and give me your real name.", TextFormat_SecurityGuard, true);
                    }

                    input = ReadLine();
                }
            }

            return input;
        }

        void IntroText(bool DefaultUsed) //The Boss spouts some exposition at the player, and sends them on their way to the tutorial.
        {
            if (!DefaultUsed)
            {
                if (protag.Name.ToLower().Contains("richard") || protag.Name.ToLower().Contains("mcconnell")) //If the player uses the real name of our protagonist, use some special dialogue.
                {
                    Game_PrintMessage($"Good to know you're honest, at least, judging by the fact that {protag.Name} is what's listed on your file...", TextFormat_SecurityGuard);
                }
                else
                {
                    Game_PrintMessage($"...{protag.Name} is not what your file says, but whatever.", TextFormat_SecurityGuard);
                }
            }

            Game_PrintMessage("I'm Bill. I've been asked to escort you to the boss's office, so I guess I'm joining your party. Follow me.", TextFormat_SecurityGuard);
            GainBill();
        }

        void GainBill()
        {
            protag.Allies.Add(new PartyMember("Bill", 50, 4, 16, 14, 12, 4));
            protag.Allies[0].Skills.Add(new Ability("Taunt", $@"{protag.Allies[0].Name} viciously attacks the target with a series of scathing remarks.
If successful, the target is forced to attack {protag.Allies[0].Name} on its next turn.", 3, 1));
            protag.Allies[0].Skills.Add(new Ability("Charge", $@"{protag.Allies[0].Name} charges up, causing his next attack to inflict triple damage.", 4, 0));

            FollowBill();
        }

        void FollowBill()
        {
            Game_PrintMessage("You follow Bill, as asked. In the elevator on the way to the Boss' office, you encounter a scientist who clearly isn't in his right mind.", TextFormat_Narrator);
            Game_PrintMessage("You have an odd premonition that this scientist's name is William. You don't know why. He decides to follow you.", TextFormat_Narrator);

            GainWilliam();
            AlmostThere();
        }

        void GainWilliam()
        {
            protag.Allies.Add(new PartyMember("William", 20, 12, 4, 8, 4, 12));
            protag.Allies[1].Skills.Add(new Ability("Suspicious Syringe", $@"{protag.Allies[1].Name} injects an ally with a dubious syringe, healing them for a random amount of health.
Healing improves with the user's intellect.", 5, 2));
            protag.Allies[1].Skills.Add(new Ability("Infection Injection", $@"{protag.Allies[1].Name} injects an enemy with a suspicious syringe, dealing a random amount of damage and inflicting poison.
Damage improves with the user's speed.", 6, 1, 2));
        }

        void AlmostThere()
        {
            Game_PrintMessage("You finally made it to the Boss' office. While in the waiting room, you notice a vending machine, and decide to get some snacks.", TextFormat_Narrator);
            protag.PlayerInv.GiveItem_Message(new Item("Vending Machine Burger", "A very questionable burger purchased from a vending machine. You've never seen anything like it before, but you feel like it will heal you for precisely 20 HP.", 0, true), 3, "purchased");
            protag.PlayerInv.GiveItem_Message(new Item("Extremely Caffeinated Soda", "The label advertises a level of caffeine so absurd that it could bring back the dead. Revives an ally with 30% HP.", 1, true), 2, "also purchased");

            List<Enemy> EnemyList = new List<Enemy>();
            EnemyList.Add(new Enemy("Your Boss", 150, 300, 30, 12, 8, 2));
            new BattleSystem(EnemyList, false, "It's finally time for your exam.", true);
        }

        private void Game_PrintMessage(string dialogue, CharacterTextFormat NewSpeaker, bool SkipIt = false, bool DontClear = false)
        {
            ActiveMessage = new TextFunctions(dialogue, NewSpeaker, SkipIt, DontClear);
            while (!ActiveMessage.FinishedPrinting)
            {
                //Wait until the current message stops printing before starting a new one, otherwise things get really weird.
            }
        }
    }
}