﻿namespace GameSpace
{
    public class Item
    {
        public string ItemName { get; private set; } = "Pretty Neat Item";
        public string ItemDescription { get; private set; } = "Basic Description";
        public int ID { get; private set; } = 0; //I use an ID system when handling item activations, which lets me handle things on a case-by-case instead of relying on a catch-all that may not work.
        public bool CanUseInBattle { get; private set; } = false;

        public Item(string NewName = "Pretty Neat Item", string Description = "Basic Description", int NewID = 0, bool Battle = false)
        {
            ItemName = NewName;
            ID = NewID;
            CanUseInBattle = Battle;
            ItemDescription = Description;
        }
    }
}
