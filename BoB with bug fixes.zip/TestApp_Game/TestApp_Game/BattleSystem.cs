﻿using System;
using System.Media;
using System.Collections.Generic;
using static System.Console;
using static GameSpace.Game;
using static GameSpace.TextFunctions;

namespace GameSpace
{
    public class BattleSystem //Everything we need when conducting a fight is handled in here.
    {
        private CharacterTextFormat BattleText = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.White, false, false, false, true, false, true);
        private CharacterTextFormat RegularFormat = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.White, false, false, false, false, false, false);
        private CharacterTextFormat EndFormat = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.White, false, false, true, false, false, false);
        CharacterTextFormat SpacerFormat = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.White, false, false, true, true, false, false);
        private List<Enemy> EnemyList;
        private TextFunctions ActiveMessage;
        private bool BattleIsActive = false;
        private bool IsBossFight = false;
        private int HealingUsed = 0;
        private int AbilitiesUsed = 0;
        private int ItemsUsed = 0;

        public BattleSystem(List<Enemy> GivenEnemies, bool UseGenericIntro = true, string IntroText = "", bool Boss = false)
        {
            EnemyList = GivenEnemies;
            IsBossFight = Boss;
            StartBattle(UseGenericIntro, IntroText);
        }

        private void StartBattle(bool UseGenericIntro = true, string IntroText = "") //Starts a fight, using a given list of enemies.
        {
            BattleIsActive = true;

            GetEnemyCount(EnemyList);

            if (!UseGenericIntro)
            {
                Game_PrintMessage(IntroText, BattleText);
            }
            else
            {
                PrintGenericIntro(EnemyList);
            }

            ReadKey(true);

            if (GetPlayerSpeed() >= GetEnemySpeed(EnemyList))
            {
                StartPlayerTurn();
            }
            else
            {
                StartEnemyTurn();
            }

            InBattle = true;
        }

        private void StartPlayerTurn() //Starts the player's turn.
        {
            if (BattleIsActive && !CheckForWin())
            {
                protag.Battle_Defending = false;
                ChoosePlayerAction(protag);

                foreach (PartyMember friendly in protag.Allies)
                {
                    if (CheckForWin())
                    {
                        PlayerWon();
                    }
                    else if (BattleIsActive)
                    {
                        friendly.Battle_Defending = false;
                        if (!friendly.Fainted)
                        {
                            ChoosePlayerAction(friendly);
                        }
                    }
                }

                if (BattleIsActive)
                {
                    StartEnemyTurn();
                }
            }
            else
            {
                PlayerWon();
            }
        }

        private void ChoosePlayerAction(Player Ally) //Allows the player to control their party members' actions. I ran out of time and wasn't able to refactor Special or Item, so they're fairly sloppy.
        {
            bool ActionTaken = false;

            while (!ActionTaken)
            {
                int ActionID = GetActionID(Ally.Name);

                switch (ActionID)
                {
                    case 1: //Attack
                        ActionTaken = DetermineAction(Ally, 1, "ATTACK");

                        break;

                    case 2: //Special
                        if (Ally.Skills.Count <= 0)
                        {
                            DrawBattleHUD(Ally.Name);
                            ForegroundColor = ConsoleColor.DarkCyan;
                            Game_PrintMessage(Ally.Name, RegularFormat, true, true);
                            ForegroundColor = getColor();
                            Game_PrintMessage(" was going to use a special ability, but he has none.", EndFormat, false, true);
                        }
                        else
                        {
                            DrawBattleHUD(Ally.Name);
                            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE: ", ConsoleColor.Yellow, EndFormat);
                            Ally.ShowAbilities();
                            int ChosenSkillID = AttemptIntConversion(ReadLine()) - 1;

                            while (!IsValidAbility(ChosenSkillID, Ally))
                            {
                                DrawBattleHUD(Ally.Name);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE: ", ConsoleColor.Yellow, EndFormat);
                                Ally.ShowAbilities();
                                ChosenSkillID = AttemptIntConversion(ReadLine()) - 1;
                            }

                            DrawBattleHUD(Ally.Name, Ally.Skills[ChosenSkillID].AbilityTargetMode);
                            if (Ally.Skills[ChosenSkillID].AbilityTargetMode == 1)
                            {
                                int TargetID = PlayerGetTarget(Ally, $"ACTIVATE {Ally.Skills[ChosenSkillID].AbilityName} on the following target: ");

                                DrawBattleHUD(Ally.Name);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE", ConsoleColor.Yellow, Ally.Skills[ChosenSkillID].AbilityName, ConsoleColor.Yellow, RegularFormat);
                                Game_PrintMessage(" on ", RegularFormat, true, true);
                                ForegroundColor = ConsoleColor.DarkRed;
                                Game_PrintMessage(EnemyList[TargetID].EnemyName + ".", SpacerFormat, false, true);
                                PrintConfirmationMessage();

                                string response = ReadLine();
                                if (response == "")
                                {
                                    ActivateSpecial(Ally, EnemyList[TargetID], Ally.Skills[ChosenSkillID]);
                                    AbilitiesUsed++;
                                    ActionTaken = true;
                                }
                            }
                            else if (Ally.Skills[ChosenSkillID].AbilityTargetMode == 2)
                            {
                                DrawBattleHUD(Ally.Name, 2);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE", ConsoleColor.Yellow, Ally.Skills[ChosenSkillID].AbilityName, ConsoleColor.Yellow, RegularFormat);
                                Game_PrintMessage(" on: ", EndFormat, true, true);
                                int AllyID = AttemptIntConversion(ReadLine());

                                while (AllyID <= 0 || AllyID > protag.Allies.Count + 1)
                                {
                                    Game_PrintMessage("Bad number, please try again.", EndFormat, false, true);
                                    DrawBattleHUD(Ally.Name, 2);
                                    WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE", ConsoleColor.Yellow, Ally.Skills[ChosenSkillID].AbilityName, ConsoleColor.Yellow, RegularFormat);
                                    Game_PrintMessage(" on: ", EndFormat, true, true);

                                    AllyID = AttemptIntConversion(ReadLine());
                                }

                                DrawBattleHUD(Ally.Name);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE", ConsoleColor.Yellow, Ally.Skills[ChosenSkillID].AbilityName, ConsoleColor.Yellow, RegularFormat);
                                Game_PrintMessage(" on ", RegularFormat, true, true);
                                ForegroundColor = ConsoleColor.DarkCyan;

                                if (AllyID == 1)
                                {
                                    Game_PrintMessage(protag.Name + ".", SpacerFormat, false, true);
                                    PrintConfirmationMessage();

                                    string response = ReadLine();
                                    if (response == "")
                                    {
                                        ActivateSpecial(Ally, protag, Ally.Skills[ChosenSkillID]);
                                        AbilitiesUsed++;
                                        ActionTaken = true;
                                    }
                                }
                                else
                                {
                                    AllyID -= 2;
                                    Game_PrintMessage(protag.Allies[AllyID].Name + ".", SpacerFormat, false, true);
                                    PrintConfirmationMessage();

                                    string response = ReadLine();
                                    if (response == "")
                                    {
                                        ActivateSpecial(Ally, protag.Allies[AllyID], Ally.Skills[ChosenSkillID]);
                                        AbilitiesUsed++;
                                        ActionTaken = true;
                                    }
                                }
                            }
                            else
                            {
                                DrawBattleHUD(Ally.Name);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "ACTIVATE", ConsoleColor.Yellow, Ally.Skills[ChosenSkillID].AbilityName, ConsoleColor.Yellow, RegularFormat);
                                Game_PrintMessage(" on ", RegularFormat, true, true);
                                ForegroundColor = ConsoleColor.DarkCyan;
                                Game_PrintMessage("himself.", SpacerFormat, false, true);

                                PrintConfirmationMessage();

                                string response = ReadLine();
                                if (response == "")
                                {
                                    ActivateSpecial(Ally, Ally.Skills[ChosenSkillID]);
                                    ActionTaken = true;
                                }
                            }
                        }

                        break;

                    case 3: //Item
                        if (protag.PlayerInv.NoBattleItems())
                        {
                            DrawBattleHUD(Ally.Name);
                            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "use an item!", ConsoleColor.Yellow, SpacerFormat);
                            ReadKey(true);
                            WriteLine("");
                            Game_PrintMessage("...But there were no usable items.", RegularFormat, true, true);
                            ReadKey(true);
                        }
                        else
                        {
                            DrawBattleHUD(Ally.Name);
                            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "USE: ", ConsoleColor.Yellow, EndFormat);
                            protag.PlayerInv.ViewInventory(false, true);
                            int ChosenItemID = AttemptIntConversion(ReadLine()) - 1;

                            while (!IsValidItem(ChosenItemID, Ally))
                            {
                                DrawBattleHUD(Ally.Name);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "USE: ", ConsoleColor.Yellow, EndFormat);
                                protag.PlayerInv.ViewInventory(false, true);
                                ChosenItemID = AttemptIntConversion(ReadLine()) - 1;
                            }

                            DrawBattleHUD(Ally.Name, 2);
                            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "USE", ConsoleColor.Yellow, protag.PlayerInv.Items[ChosenItemID].ItemName, ConsoleColor.Yellow, RegularFormat);
                            Game_PrintMessage(" on: ", EndFormat, true, true);

                            int AllyID = AttemptIntConversion(ReadLine());

                            while (AllyID <= 0 || AllyID > protag.Allies.Count + 1)
                            {
                                Game_PrintMessage("Bad number, please try again.", EndFormat, false, true);
                                DrawBattleHUD(Ally.Name, 2);
                                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "USE", ConsoleColor.Yellow, protag.PlayerInv.Items[ChosenItemID].ItemName, ConsoleColor.Yellow, RegularFormat);
                                Game_PrintMessage(" on: ", EndFormat, true, true);

                                AllyID = AttemptIntConversion(ReadLine());
                            }

                            DrawBattleHUD(Ally.Name);
                            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "USE", ConsoleColor.Yellow, protag.PlayerInv.Items[ChosenItemID].ItemName, ConsoleColor.Yellow, RegularFormat);
                            Game_PrintMessage(" on ", RegularFormat, true, true);
                            ForegroundColor = ConsoleColor.DarkCyan;

                            if (AllyID == 1)
                            {
                                Game_PrintMessage(protag.Name + ".", SpacerFormat, false, true);
                                PrintConfirmationMessage();
                                string response = ReadLine();

                                if (response == "")
                                {
                                    DrawBattleHUD(Ally.Name, 0, -1, protag.Name);
                                    ForegroundColor = ConsoleColor.DarkCyan;
                                    Game_PrintMessage(Ally.Name, RegularFormat, true, true);
                                    ForegroundColor = ConsoleColor.Yellow;
                                    Game_PrintMessage($" USED the {protag.PlayerInv.Items[ChosenItemID].ItemName} ", RegularFormat, true, true);
                                    ForegroundColor = getColor();
                                    Game_PrintMessage("on ", RegularFormat, true, true);
                                    ForegroundColor = ConsoleColor.DarkCyan;
                                    Game_PrintMessage($"{protag.Name}.", SpacerFormat, false, true);
                                    ForegroundColor = getColor();

                                    switch (protag.PlayerInv.Items[ChosenItemID].ID) //I only have 2 items, ID 0 and ID 1, which are a healing item and a revive item respectively.
                                    {
                                        case 0:
                                            if (protag.CurrentHealth < protag.MaxHealth)
                                            {
                                                int BurgerHeal = 20;
                                                HealTarget(protag, BurgerHeal);
                                            }
                                            else
                                            {
                                                Game_PrintMessage("...But nothing happened!", EndFormat, false, true);
                                            }

                                            break;

                                        case 1: //We can't use revive items on the protag, because if they faint, the game immediately ends. Therefore, because it is impossible to revive the protagonist, we don't need to use the revive logic here.
                                            Game_PrintMessage("...But nothing happened!", EndFormat, false, true);

                                            break;

                                    }

                                    protag.PlayerInv.RemoveItem(ChosenItemID);
                                    ItemsUsed++;
                                    ActionTaken = true;
                                }
                            }
                            else
                            {
                                AllyID -= 2;
                                Game_PrintMessage(protag.Allies[AllyID].Name + ".", SpacerFormat, false, true);
                                PrintConfirmationMessage();
                                string response = ReadLine();

                                if (response == "")
                                {
                                    DrawBattleHUD(Ally.Name, 0, -1, protag.Allies[AllyID].Name);
                                    ForegroundColor = ConsoleColor.DarkCyan;
                                    Game_PrintMessage(Ally.Name, RegularFormat, true, true);
                                    ForegroundColor = ConsoleColor.Yellow;
                                    Game_PrintMessage($" USED the {protag.PlayerInv.Items[ChosenItemID].ItemName} ", RegularFormat, true, true);
                                    ForegroundColor = getColor();
                                    Game_PrintMessage("on ", RegularFormat, true, true);
                                    ForegroundColor = ConsoleColor.DarkCyan;
                                    Game_PrintMessage($"{protag.Allies[AllyID].Name}.", SpacerFormat, false, true);
                                    ForegroundColor = getColor();

                                    switch(protag.PlayerInv.Items[ChosenItemID].ID) //I only have 2 items, ID 0 and ID 1, which are a healing item and a revive item respectively.
                                    {
                                        case 0:
                                            if (!protag.Allies[AllyID].Fainted && protag.Allies[AllyID].CurrentHealth < protag.Allies[AllyID].MaxHealth)
                                            {
                                                int BurgerHeal = 20;
                                                HealTarget(protag.Allies[AllyID], BurgerHeal);
                                            }
                                            else
                                            {
                                                Game_PrintMessage("...But nothing happened!", EndFormat, false, true);
                                            }

                                            break;

                                        case 1:
                                            if (protag.Allies[AllyID].Fainted)
                                            {
                                                int ReviveDividend = 3;

                                                protag.Allies[AllyID].ChangeHP(protag.Allies[AllyID].MaxHealth / ReviveDividend);
                                                protag.Allies[AllyID].Fainted = false;

                                                ForegroundColor = ConsoleColor.DarkCyan;
                                                Game_PrintMessage(protag.Allies[AllyID].Name, RegularFormat, true, true);
                                                ForegroundColor = getColor();
                                                Game_PrintMessage(" was ", RegularFormat, true, true);
                                                ForegroundColor = ConsoleColor.Green;
                                                Game_PrintMessage("revived!", SpacerFormat, false, true);
                                            }
                                            else
                                            {
                                                Game_PrintMessage("...But nothing happened!", EndFormat, false, true);
                                            }

                                            break;

                                    }

                                    protag.PlayerInv.RemoveItem(ChosenItemID);
                                    ItemsUsed++;
                                    ActionTaken = true;
                                }
                            }

                            ReadKey(true);
                        }

                        break;


                    case 4: //Defend
                        bool DefenseChosen = AllyDefense(Ally);
                        Ally.Battle_Defending = DefenseChosen;
                        ActionTaken = DefenseChosen;

                        break;

                    case 5: //Check
                        ActionTaken = DetermineAction(Ally, 2, "CHECK");

                        break;

                    case 6: //Run
                        DrawBattleHUD(Ally.Name);
                        WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "RUN. ", ConsoleColor.Yellow, SpacerFormat);
                        PrintConfirmationMessage();

                        string response123123 = ReadLine();

                        if (response123123 == "")
                        {
                            ActionTaken = true;
                            AttemptToRun(Ally.Name);
                        }

                        break;
                    default:
                        break;


                }
            }
        }

        private void ActivateSpecial(Player User, Enemy Target, Ability Skill) //Specials that target enemies.
        {
            DrawBattleHUD(User.Name, 0, -1, Target.EnemyName);

            int SkillID = Skill.AbilityIndex;

            switch(SkillID)
            {
                case 1: //Mind Bender
                    int BaseConfusionChance = 5 * (User.Intellect - Target.EnemyIntellect);
                    if (BaseConfusionChance < 0)
                    {
                        BaseConfusionChance = 0;
                    }

                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" attempts to twist ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.DarkRed;
                    Game_PrintMessage(Target.EnemyName + "'s ", RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage("mind...", SpacerFormat, false, true);

                    bool Success = false;

                    if (BaseConfusionChance > 0)
                    {
                        Random ConfChance = new Random();

                        Success = (BaseConfusionChance >= ConfChance.Next(1, 100));
                    }

                    if (Success)
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                        Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                        ForegroundColor = getColor();
                        Game_PrintMessage(" is confused!", SpacerFormat, false, true);
                        Target.Battle_MindBent = true;
                    }
                    else
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                        Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                        ForegroundColor = getColor();
                        Game_PrintMessage(" resisted the confusion.", SpacerFormat, false, true);
                    }

                    int Damage = Skill.AbilityDamage;

                    Damage *= (int)Math.Round(User.Intellect * 0.165);

                    InflictDamage(Target, Damage, User.Name, false);

                    break;
                case 3: //Taunt
                    int BaseTauntSuccess = 70 - (Target.EnemyIntellect - User.Intellect);

                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" hurls some insults at ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.DarkRed;
                    Game_PrintMessage(Target.EnemyName + ".", SpacerFormat, true, true);
                    ForegroundColor = getColor();

                    bool Success2 = false;

                    if (BaseTauntSuccess > 0)
                    {
                        Random TauntChance = new Random();

                        Success2 = (BaseTauntSuccess >= TauntChance.Next(1, 100));
                    }

                    if (Success2)
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                        Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                        ForegroundColor = getColor();
                        Game_PrintMessage(" is enraged!", SpacerFormat, false, true);
                        Target.Battle_Enraged = true;
                        Target.Battle_Enraged_Target = User;
                    }
                    else
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                        Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                        ForegroundColor = getColor();
                        Game_PrintMessage(" didn't care.", SpacerFormat, false, true);
                    }

                    break;

                case 6: //Infection Injection
                    int DMG = Skill.AbilityDamage * (User.Speed / 2);

                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" pokes ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.DarkRed;
                    Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" with a very dubious syringe!", SpacerFormat, false, true);

                    InflictDamage(Target, DMG, User.Name, false);
                    WriteLine("");

                    if (Target.PoisonCounter == 0)
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                        Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
                        ForegroundColor = getColor();
                        Game_PrintMessage(" was poisoned!", SpacerFormat, false, true);
                        Target.PoisonCounter += 3;
                    }

                    break;
            }
        }

        private void ActivateSpecial(Player User, Player Target, Ability Skill)
        {
            DrawBattleHUD(User.Name, 0, -1, Target.Name);

            int SkillID = Skill.AbilityIndex;

            switch (SkillID)
            {
                case 2: //Psychic Barrier
                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" envelops ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(Target.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" in a psychic barrier!", SpacerFormat, false, true);
                    Target.Battle_PsyBarrier = true;

                    break;

                case 5: //Suspicious Syringe
                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" whips out a very questionable syringe and injects it into ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(Target.Name + "!", SpacerFormat, true, true);
                    ForegroundColor = getColor();

                    int MinHeal = User.Intellect / 4;
                    int MaxHeal = User.Intellect;

                    Random RandHeal = new Random();

                    HealTarget(Target, RandHeal.Next(MinHeal, MaxHeal));

                    break;
            }
        }

        private void ActivateSpecial(Player User, Ability Skill)
        {
            DrawBattleHUD(User.Name);

            int SkillID = Skill.AbilityIndex;

            switch (SkillID)
            {
                case 4: //Charge
                    ForegroundColor = ConsoleColor.DarkCyan;
                    Game_PrintMessage(User.Name, RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage(" began charging his next attack!", SpacerFormat, false, true);

                    if (User.Battle_Charging)
                    {
                        Game_PrintMessage("...But he was already charging.", SpacerFormat, false, true);
                    }
                    else
                    {
                        User.Battle_Charging = true;
                    }

                    break;
            }
        }

        private void HealTarget(Player Target, int Heal)
        {
            int MissingHealth = Target.MaxHealth - Target.CurrentHealth;

            if (Heal > MissingHealth)
            {
                Heal = MissingHealth;
            }

            Target.ChangeHP(Heal);
            HealingUsed += Heal;

            ForegroundColor = ConsoleColor.DarkCyan;
            Game_PrintMessage(Target.Name, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" was healed for ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.Green;
            Game_PrintMessage($"{Heal} HP!", SpacerFormat, false, true);
            ForegroundColor = getColor();
            ReadKey(true);
        }

        private bool IsValidItem(int ItemID, Player Ally)
        {
            bool Valid = false;

            if (ItemID > -1 && ItemID <= protag.PlayerInv.Items.Count)
            {
                if (!protag.PlayerInv.Items[ItemID].CanUseInBattle)
                {
                    ForegroundColor = ConsoleColor.Yellow;
                    Game_PrintMessage(protag.PlayerInv.Items[ItemID].ItemName + " ", RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage("cannot be used in a battle.", RegularFormat, true, true);
                    ReadKey(true);
                }
                else
                {
                    Valid = true;
                }
            }
            else
            {
                Game_PrintMessage("Bad number, please try again.", RegularFormat, true, true);
                ReadKey(true);
            }

            if (Valid)
            {
                DrawBattleHUD(Ally.Name);
                ForegroundColor = ConsoleColor.Yellow;
                Game_PrintMessage(protag.PlayerInv.Items[ItemID].ItemName + ": ", RegularFormat, true, true);
                ForegroundColor = getColor();
                Game_PrintMessage(protag.PlayerInv.Items[ItemID].ItemDescription, SpacerFormat, true, true);
                WriteLine("");
                Game_PrintMessage("Press ENTER to select a target to use this item on, or type a message to go back and select a different item.", EndFormat, true, true);

                if (ReadLine() != "")
                {
                    Valid = false;
                }
            }

            return Valid;
        }

        private bool IsValidAbility(int SkillID, Player Ally)
        {
            bool Valid = false;

            if (SkillID > -1 && SkillID < Ally.Skills.Count)
            {
                Valid = true;
            }
            else
            {
                Game_PrintMessage("Bad number, please try again.", RegularFormat, true, true);
                ReadKey(true);
            }

            if (Valid)
            {
                DrawBattleHUD(Ally.Name);
                ForegroundColor = ConsoleColor.Yellow;
                Game_PrintMessage(Ally.Skills[SkillID].AbilityName + ": ", RegularFormat, true, true);
                ForegroundColor = getColor();
                Game_PrintMessage(Ally.Skills[SkillID].AbilityDescription, SpacerFormat, true, true);
                WriteLine("");
                Game_PrintMessage("Press ENTER to select a target to use this ability on, or type a message to go back and select a different special.", EndFormat, true, true);

                if (ReadLine() != "")
                {
                    Valid = false;
                }
            }

            return Valid;
        }

        private bool DetermineAction(Player Ally, int ActionType, string ActionDisplay) //Single method that allows the player to attack or check an enemy. Originally, attack and check were separate methods, but they used a *lot* of shared code, so I merged them.
        {
            bool ActionFinished = false;
            bool TargetChosen = false;
            int TargetID = -1;

            while (!TargetChosen)
            {
                TargetID = PlayerGetTarget(Ally, ActionDisplay + ": ");

                if (TargetID != -1)
                {
                    DrawBattleHUD(Ally.Name, 1, TargetID);
                    WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, ActionDisplay, ConsoleColor.Yellow, EnemyList[TargetID].EnemyName + ". ", ConsoleColor.DarkRed, SpacerFormat);

                    PrintConfirmationMessage();

                    TargetChosen = true;

                    string response = ReadLine();

                    ActionFinished = (response == "");
                }
            }

            if (ActionFinished)
            {
                switch (ActionType)
                {
                    case 1:
                        StandardAttack(Ally, EnemyList[TargetID]);
                        break;
                    default:
                        CheckEnemy(Ally.Name, EnemyList[TargetID]);
                        break;
                }
            }

            return ActionFinished;
        }

        private int PlayerGetTarget(Player Ally, string ActionDisplay) //Returns the player's selected target.
        {
            int TargetID = -1;

            string TargetName;
            bool TargetFound = false;

            while (!TargetFound)
            {
                DrawBattleHUD(Ally.Name, 1);
                WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, ActionDisplay, ConsoleColor.Yellow, EndFormat);
                TargetID = AttemptIntConversion(ReadLine()) - 1;

                try
                {
                    TargetName = EnemyList[TargetID].EnemyName;
                    TargetFound = true;
                }
                catch (ArgumentOutOfRangeException)
                {
                    DrawBattleHUD(Ally.Name);
                    Game_PrintMessage("Invalid target. Please ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.Yellow;
                    Game_PrintMessage("enter a number ", RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage("and try again.", EndFormat, true, true);
                    ReadKey(true);
                }
            }

            return TargetID;
        }

        private void CheckEnemy(string Checker, Enemy Target) //Checks the target's stats.
        {
            DrawBattleHUD(Checker, 0, -1, Target.EnemyName);

            ForegroundColor = ConsoleColor.DarkCyan;
            Game_PrintMessage(Checker, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" analyzes ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(Target.EnemyName + "...", SpacerFormat, true, true);
            ForegroundColor = getColor();

            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(Target.EnemyName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" has: ", SpacerFormat, false, true);
            Game_PrintMessage($"{Target.EnemyHP}/{Target.EnemyMaxHP} Health.", SpacerFormat, false, true);
            Game_PrintMessage($"{Target.EnemyStrength} Strength.", SpacerFormat, false, true);
            Game_PrintMessage($"{Target.EnemyDefense} Defense.", SpacerFormat, false, true);
            Game_PrintMessage($"{Target.EnemySpeed} Speed.", SpacerFormat, false, true);
            Game_PrintMessage($"{Target.EnemyIntellect} Intellect.", SpacerFormat, false, true);
        }

        private bool AllyDefense(Player Ally) //Allows a friendly unit to defend.
        {
            bool PlayerDefended = false;
            DrawBattleHUD(Ally.Name);
            WriteBattleActionText(Ally.Name, ConsoleColor.DarkCyan, "DEFEND. ", ConsoleColor.Yellow, SpacerFormat);

            PrintConfirmationMessage();

            string response2 = ReadLine();

            if (response2 == "")
            {
                PlayerDefended = true;
            }

            return PlayerDefended;
        }

        private void AttemptToRun(string Runner) //Allows the player to attempt to flee from combat.
        {
            DrawBattleHUD(Runner);
            ForegroundColor = ConsoleColor.DarkCyan;
            Game_PrintMessage(Runner, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" searched for a way out...", SpacerFormat, true, true);
            ReadKey(true);

            if (IsBossFight) //Skip unnecessary calculations if this is a fight we aren't allowed to run from.
            {
                ForegroundColor = ConsoleColor.Red;
                if (Runner == protag.Name)
                {
                    Game_PrintMessage("...But then he realized he'd probably be fired if he tried to run.", EndFormat, false, true);
                }
                else
                {
                    Game_PrintMessage($"...But he didn't want to go back to his boring job, so he decided to stay and fight.", EndFormat, false, true);
                }
            }
            else //Calculate the chance to escape, then end the fight if successful.
            {
                int BaseChance = 10 + (GetPlayerSpeed() - GetEnemySpeed(EnemyList));

                BaseChance *= (BaseChance - 5);

                bool WillEscape = false;

                if (BaseChance > 0)
                {
                    Random RandChance = new Random();
                    WillEscape = (RandChance.Next(1, 100) <= BaseChance);
                }

                if (WillEscape)
                {
                    ForegroundColor = ConsoleColor.Green;
                    Game_PrintMessage("Got away safely!", EndFormat, false, true);
                    BattleIsActive = false;
                }
                else
                {
                    ForegroundColor = ConsoleColor.Red;
                    Game_PrintMessage("Unsuccessful...", EndFormat, false, true);
                }
            }

            ForegroundColor = getColor();
        }

        private void StandardAttack(Player Attacker, Enemy Victim) //Normal (non-ability) party member attacks.
        {
            //Damage is equal to the difference between the attacker's strength and the victim's defense.
            //All attacks are susceptible to a 33% random spread.
            //All attacks have a chance to inflict critical damage, which multiplies the damage dealt by 3.
            //Crit chance is directly related to the attacker's luck.
            //For obivous reasons, damage can't fall below zero.

            int Damage = (Attacker.Strength) - (Victim.EnemyDefense);

            Random DamageSpread = new Random();

            if (Damage > 0)
            {
                int DamageModifier = DamageSpread.Next(0, Damage / 3);

                if (DamageSpread.Next(1, 2) == 2)
                {
                    DamageModifier *= -1;
                }

                Damage += DamageModifier;
            }

            bool WillCrit = (Attacker.Luck >= DamageSpread.Next(1, 100));

            if (Attacker.Battle_Charging)
            {
                Damage *= 3;
                Attacker.Battle_Charging = false;
            }

            if (WillCrit)
            {
                Damage *= 3;
            }

            if (Damage < 0)
            {
                Damage = 0;
            }

            Damage = PrintDamageMessage(Damage, Attacker.Name, Victim.EnemyName, ConsoleColor.DarkCyan, ConsoleColor.DarkRed, 0, -1);

            ReadKey(true);

            InflictDamage(Victim, Damage, Attacker.Name, WillCrit);
        }

        private void InflictDamage(Enemy Victim, int Damage, string AttackerName, bool CritMod) //Calculates damage for standard player attacks.
        {
            Victim.ChangeHP(-Damage);
            DrawBattleHUD(AttackerName, 0, -1, Victim.EnemyName);

            if (CritMod)
            {
                char[] CritMessage = "CRITICAL HIT! ".ToCharArray();

                Random RainbowText = new Random();

                int ColorUsed = RainbowText.Next(1, 4);

                for (int i = 0; i < CritMessage.Length; i++)
                {
                    switch(ColorUsed)
                    {
                        case 1:
                            ForegroundColor = ConsoleColor.Green;
                            break;
                        case 2:
                            ForegroundColor = ConsoleColor.Blue;
                            break;
                        case 3:
                            ForegroundColor = ConsoleColor.DarkRed;
                            break;
                        case 4:
                            ForegroundColor = ConsoleColor.DarkYellow;
                            break;
                    }

                    ColorUsed++;
                    if (ColorUsed > 4)
                    {
                        ColorUsed = 1;
                    }

                    Write(CritMessage[i]);
                }

                //PlayBattleSound("BasicAttack_Friendly.wav");
            }
            else
            {
                //PlayBattleSound("CritAttack_Friendly.wav");
            }

            PrintTakenMessage(Damage, Victim.EnemyName, ConsoleColor.DarkRed);

            ReadKey(true);

            if (Victim.EnemyHP <= 0)
            {
                DefeatEnemy(Victim, AttackerName);
            }
        }

        private bool CheckForWin()
        {
            return (EnemyList.Count <= 0);
        }

        private void DefeatEnemy(Enemy Victim, string AttackerName = "") //When an enemy falls to/below 0 HP, remove them from the battle and print a message.
        {
            //TODO: Add experience and leveling.

            DrawBattleHUD(AttackerName, 0, -1, Victim.EnemyName);

            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(Victim.EnemyName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" was defeated!", RegularFormat, true, true);
            EnemyList.Remove(Victim);

            ReadKey(true);
        }

        private int GetActionID(string GivenName) //Returns the player's chosen action (attack, special, item, defend, check, or run)
        {
            bool success = false;
            int ActionID = 0;

            while (!success)
            {
                DrawBattleHUD(GivenName);

                WriteBattleActionText(GivenName, ConsoleColor.DarkCyan, EndFormat);

                string PlayerAction = ReadLine();

                ActionID = AttemptIntConversion(PlayerAction);

                if (ActionID > 0 && ActionID < 7)
                {
                    success = true;
                }

                if (!success)
                {
                    DrawBattleHUD(GivenName);
                    Game_PrintMessage("I didn't understand that. Remember: ", RegularFormat, true, true);
                    ForegroundColor = ConsoleColor.Yellow;
                    Game_PrintMessage("inputs during battles must be numeric. ", RegularFormat, true, true);
                    ForegroundColor = getColor();
                    Game_PrintMessage("Press any key to try again. ", RegularFormat, true, true);
                    ReadKey(true);
                }
            }

            return ActionID;
        }

        private int AttemptIntConversion(string AllegedNumber) //Converts strings to ints, returns -1 if an error is encountered. Used when the player chooses abilities and targets.
        {
            int returnVal = -1;

            try
            {
                returnVal = Int32.Parse(AllegedNumber);
            }
            catch (FormatException)
            {
                //Nothing to do here.
            }

            return returnVal;
        }

        private void PlayerWon() //The player beat the boss, thus ending the game.
        {
            BattleIsActive = false;
            Clear();
            ForegroundColor = ConsoleColor.Green;
            Game_PrintMessage("You won!", SpacerFormat, false, true);
            ForegroundColor = getColor();
            Game_PrintMessage("Over the course of that battle, you: ", SpacerFormat, false, true);
            Game_PrintMessage($"Used {ItemsUsed} items.", SpacerFormat, false, true);
            Game_PrintMessage($"Activated {AbilitiesUsed} abilities.", SpacerFormat, false, true);
            Game_PrintMessage($"Healed a total of {HealingUsed} HP.", SpacerFormat, false, true);
            Game_PrintMessage($"Your final score was {(ItemsUsed * 5) + (AbilitiesUsed * 10) + (HealingUsed * 2)}.", SpacerFormat, false, true);
            Game_PrintMessage("Would you like to play again? [Y/N]", SpacerFormat, true, true);

            string response = ReadLine();
            if (ResponseIsConfirmation(response))
            {
                new Game("Richard McConnell", "Boss of Bosses", 180, 50, ConsoleColor.White);
            }
            else
            {
                Environment.Exit(0);
            }
        }

        private void StartEnemyTurn()  //Starts the enemy's turn.
        {
            if (BattleIsActive)
            {
                for (int CurrentOpponent = 0; CurrentOpponent < EnemyList.Count; CurrentOpponent++) //This was originally a foreach loop, but when I introduced effects that damage the enemy at the start of their turn (such as Mind Bender), I had to convert to a for loop, as defeating enemies during the foreach would crash the game.
                {
                    if (CheckForWin())
                    {
                        PlayerWon();
                    }
                    else if (BattleIsActive)
                    {
                        if (CurrentOpponent > 0)
                        {
                            if (EnemyList[CurrentOpponent - 1].EnemyHP <= 0)
                            {
                                DefeatEnemy(EnemyList[CurrentOpponent]);
                            }
                        }

                        DrawBattleHUD(EnemyList[CurrentOpponent].EnemyName);

                        if (EnemyList[CurrentOpponent].PoisonCounter > 0)
                        {
                            PoisonDamage(EnemyList[CurrentOpponent]);
                        }
                        if (EnemyList[CurrentOpponent].EnemyHP <= 0)
                        {
                            DefeatEnemy(EnemyList[CurrentOpponent]);
                            CurrentOpponent--;
                        }

                        if (EnemyList[CurrentOpponent].Battle_MindBent)
                        {
                            MindBendSelfHarm(EnemyList[CurrentOpponent]);

                            if (EnemyList[CurrentOpponent].EnemyHP <= 0)
                            {
                                DefeatEnemy(EnemyList[CurrentOpponent]);
                                CurrentOpponent--;
                            }
                            else
                            {
                                EnemyList[CurrentOpponent].Battle_MindBent = false;
                            }
                        }
                        else if (EnemyList[CurrentOpponent].Battle_Enraged && EnemyList[CurrentOpponent].Battle_Enraged_Target.CurrentHealth > 0)
                        {
                            StandardAttack(EnemyList[CurrentOpponent], EnemyList[CurrentOpponent].Battle_Enraged_Target);

                            WriteLine("");
                            ForegroundColor = ConsoleColor.DarkRed;
                            Game_PrintMessage(EnemyList[CurrentOpponent].EnemyName, RegularFormat, true, true);
                            ForegroundColor = getColor();
                            Game_PrintMessage("'s rage has subsided.", SpacerFormat, false, true);
                            EnemyList[CurrentOpponent].Battle_Enraged = false;
                        }
                        else
                        {
                            Random EnemyAction = new Random();

                            switch (EnemyAction.Next(1, 1)) //TODO: Give enemies different actions besides just attacking.
                            {
                                case 1:
                                    EnemyAttack(EnemyList[CurrentOpponent]);
                                    break;
                            }
                        }

                        ReadKey(true);
                    }
                }

                if (BattleIsActive)
                {
                    StartPlayerTurn();
                }
            }
        }

        private void PoisonDamage(Enemy Victim)
        {
            int PoisonDMG = 2;

            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(Victim.EnemyName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" took ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage($"{PoisonDMG}", RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" damage from their poison!", SpacerFormat, false, true);

            Victim.ChangeHP(-PoisonDMG);

            Victim.PoisonCounter--;

            if (Victim.PoisonCounter < 1)
            {
                ForegroundColor = ConsoleColor.DarkRed;
                Game_PrintMessage(Victim.EnemyName, RegularFormat, true, true);
                ForegroundColor = getColor();
                Game_PrintMessage(" is no longer poisoned.", SpacerFormat, false, true);
            }
        }

        private void MindBendSelfHarm(Enemy victim) //If the protagonist's unique "Mind Bender" ability successfully confuses the target, damage that target when they begin their turn.
        {
            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(victim.EnemyName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" attacks itself in its confusion!", SpacerFormat, false, true);

            int Damage = victim.EnemyStrength - victim.EnemyDefense;
            if (Damage < 0)
            {
                Damage = 0;
            }
            victim.ChangeHP(-Damage);

            ForegroundColor = ConsoleColor.DarkRed;
            Game_PrintMessage(victim.EnemyName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" took ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.DarkRed;
            Write(Damage);
            ForegroundColor = getColor();
            Game_PrintMessage(" damage!", SpacerFormat, false, true);
        }

        private void EnemyAttack(Enemy attacker) //Triggers a non-ability enemy attack. Varies based on whether or not the victim is the protagonist.
        {
            int PartySize = GetPartySize();

            Random RandTarg = new Random();

            int TargetID = RandTarg.Next(0, PartySize);

            if (TargetID == 0 || AllAlliesAreDead())
            {
                StandardAttack(attacker, protag);
            }
            else
            {
                bool Chosen = false;

                while (!Chosen)
                {
                    if (!protag.Allies[TargetID - 1].Fainted)
                    {
                        Chosen = true;
                    }
                    else
                    {
                        TargetID = RandTarg.Next(1, PartySize);
                    }
                }

                StandardAttack(attacker, protag.Allies[TargetID - 1]);
            }
        }

        private void StandardAttack(Enemy Attacker, Player Victim) //Calculates damage for normal (non-ability) enemy attacks. Varies based on whether or not the victim is the protagonist.
        {
            int Damage = (Attacker.EnemyStrength) - (Victim.Defense);

            if (Damage > 0)
            {
                Random DamageSpread = new Random();
                int DamageModifier = DamageSpread.Next(0, Damage / 3);

                if (DamageSpread.Next(1, 2) == 2)
                {
                    DamageModifier *= -1;
                }

                Damage += DamageModifier;
            }

            Damage = PrintDamageMessage(Damage, Attacker.EnemyName, Victim.Name, ConsoleColor.DarkRed, ConsoleColor.DarkCyan, 2, -1, Victim.Battle_Defending, Victim.Battle_PsyBarrier);
            if (Victim.Battle_PsyBarrier)
            {
                Victim.Battle_PsyBarrier = false;
            }

            ReadKey(true);

            InflictDamage(Victim, Damage, Attacker.EnemyName);
        }

        private void StandardAttack(Enemy Attacker, PartyMember Victim)
        {
            int Damage = (Attacker.EnemyStrength) - (Victim.Defense);

            if (Damage > 0)
            {

                Random DamageSpread = new Random();
                int DamageModifier = DamageSpread.Next(0, Damage / 3);

                if (DamageSpread.Next(1, 2) == 2)
                {
                    DamageModifier *= -1;
                }

                Damage += DamageModifier;
            }

            Damage = PrintDamageMessage(Damage, Attacker.EnemyName, Victim.Name, ConsoleColor.DarkRed, ConsoleColor.DarkCyan, 2, -1, Victim.Battle_Defending, Victim.Battle_PsyBarrier);
            if (Victim.Battle_PsyBarrier)
            {
                Victim.Battle_PsyBarrier = false;
            }

            ReadKey(true);

            InflictDamage(Victim, Damage, Attacker.EnemyName);
        }

        private void InflictDamage(Player Victim, int Damage, string AttackerName) //Inflicts damage when an enemy attacks a player. Varies based on whether or not the victim is the protagonist.
        {
            if (Damage < 0)
            {
                Damage = 0;
            }

            Victim.ChangeHP(-Damage);
            DrawBattleHUD(AttackerName, 2, -1, Victim.Name);

            PrintTakenMessage(Damage, Victim.Name, ConsoleColor.DarkCyan);

            if (Victim.CurrentHealth <= 0)
            {
                ReadKey(true);
                FaintAlly(Victim, AttackerName);
            }
        }

        private void InflictDamage(PartyMember Victim, int Damage, string AttackerName)
        {
            if (Damage < 0)
            {
                Damage = 0;
            }

            Victim.ChangeHP(-Damage);
            DrawBattleHUD(AttackerName, 2, -1, Victim.Name);

            PrintTakenMessage(Damage, Victim.Name, ConsoleColor.DarkCyan);

            if (Victim.CurrentHealth <= 0)
            {
                ReadKey(true);
                FaintAlly(Victim, AttackerName);
            }
        }

        private void PrintTakenMessage(int dmg, string VictimName, ConsoleColor VictimColor) //Prints the message that gets displayed when a unit takes damage.
        {
            ForegroundColor = VictimColor;
            Game_PrintMessage(VictimName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" took ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.Yellow;
            Game_PrintMessage(Convert.ToString(dmg), RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" damage!", RegularFormat, true, true);
        }

        private int PrintDamageMessage(int dmg, string AttackerName, string VictimName, ConsoleColor AttackerColor, ConsoleColor VictimColor, int TargetMode = 0, int TargetID = -1, bool blocked = false, bool psybarrier = false) //Prints the message that gets displayed when an attack is launched.
        {
            int Damage = dmg;
            DrawBattleHUD(AttackerName, 2, -1, VictimName);

            ForegroundColor = AttackerColor;
            Game_PrintMessage(AttackerName, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" attacks ", RegularFormat, true, true);
            ForegroundColor = VictimColor;
            Game_PrintMessage(VictimName + "!", RegularFormat, true, true);
            ForegroundColor = getColor();

            if (blocked)
            {
                Damage = (int)Math.Round(Damage * 0.5);
                ForegroundColor = ConsoleColor.DarkCyan;
                WriteLine("");
                Game_PrintMessage(VictimName, RegularFormat, true, true);
                ForegroundColor = getColor();
                Game_PrintMessage(" blocked some of the damage!", RegularFormat, true, true);
            }

            if (psybarrier)
            {
                Damage = (int)Math.Round(Damage * 0.5);
                ForegroundColor = ConsoleColor.DarkCyan;
                WriteLine("");
                Game_PrintMessage(VictimName , RegularFormat, true, true);
                ForegroundColor = getColor();
                Game_PrintMessage("'s psychic barrier blocked half of the damage before shattering!", RegularFormat, true, true);
            }

            return Damage;
        }

        private void FaintAlly(Player victim, string AttackerName) //When a player character drops to/below 0 HP, make them faint. Varies based on whether it was the protagonist or not.
        {
            DrawBattleHUD(AttackerName, 0, -1, victim.Name);
            ForegroundColor = ConsoleColor.Red;
            Game_PrintMessage($"{victim.Name} fainted!", RegularFormat, true, true);
            ForegroundColor = getColor();
            ReadKey(true);
            if (victim.Name == protag.Name)
            {
                GameOver();
            }
            else
            {
                victim.Fainted = true;
            }
        }

        private bool AllAlliesAreDead() //Helps enemies choose who to attack. Returns true if the protagonist is the only member of the player's party who is still alive.
        {
            bool AllDead = true;

            foreach(PartyMember member in protag.Allies)
            {
                if (!member.Fainted)
                {
                    AllDead = false;
                }
            }

            return AllDead;
        }

        private void DrawBattleHUD(string ActiveUnit, int TargetMode = 0, int TargetID = -1, string TargetName = "") //Draws the battle HUD.
        {
            Clear();

            int HUDLength = 105;
            
            int RemainingEnemies = EnemyList.Count;
            int PartySize = GetPartySize();

            int LargerSize = RemainingEnemies;

            if (PartySize > RemainingEnemies)
            {
                LargerSize = PartySize;
            }

            SetCursorPosition(WindowWidth - HUDLength, (WindowHeight / 2) - LargerSize);

            List<string> AllyRow = new List<string>();
            List<string> AllyHPRow = new List<string>();
            List<ConsoleColor> HPColor = new List<ConsoleColor>();

            int AllyCounter = 1;

            bool TargetingAllies = (TargetMode == 2);

            if (TargetingAllies)
            {
                AllyRow.Add($"{AllyCounter}. {protag.Name}");
                AllyCounter++;
            }
            else
            {
                AllyRow.Add(protag.Name);
            }

            AllyHPRow.Add($" [HP: {protag.CurrentHealth}/{protag.MaxHealth}]");
            HPColor.Add(GetHealthColor(protag.CurrentHealth, protag.MaxHealth));

            foreach(PartyMember member in protag.Allies)
            {
                if (TargetingAllies)
                {
                    AllyRow.Add($"{AllyCounter}. {member.Name}");
                    AllyCounter++;
                }
                else
                {
                    AllyRow.Add(member.Name);
                }

                AllyHPRow.Add($" [HP: {member.CurrentHealth}/{member.MaxHealth}]");
                HPColor.Add(GetHealthColor(member.CurrentHealth, member.MaxHealth, member.Fainted));
            }

            List<string> FoeRow = new List<string>();

            bool TargetingEnemies = (TargetMode == 1);
            int EnemyCounter = 1;

            foreach (Enemy foe in EnemyList)
            {
                if (TargetingEnemies)
                {
                    FoeRow.Add($"{EnemyCounter}. " + foe.EnemyName);
                    EnemyCounter++;
                }
                else
                {
                    FoeRow.Add(foe.EnemyName);
                }
            }

            for (int i = LargerSize; i >= 0; i--)
            {
                if (AllyRow.Count > i)
                {
                    if (AllyRow[i] == ActiveUnit)
                    {
                        ForegroundColor = ConsoleColor.DarkCyan;
                    }
                    else if (AllyRow[i] == TargetName && AllyRow[i] != "")
                    {
                        ForegroundColor = ConsoleColor.DarkCyan;
                    }
                    else if (i == TargetID && TargetMode == 2)
                    {
                        ForegroundColor = ConsoleColor.DarkCyan;
                    }

                    if (HPColor[i] == ConsoleColor.DarkRed)
                    {
                        ForegroundColor = ConsoleColor.DarkGray;
                    }
                    Write(AllyRow[i]);
                    ForegroundColor = HPColor[i];
                    Write(AllyHPRow[i]);
                    ForegroundColor = getColor();

                    if (FoeRow.Count > i)
                    {
                        GenerateBlankSpace(HUDLength - (AllyRow[i].Length + AllyHPRow[i].Length + FoeRow[i].Length));

                        if (FoeRow[i] == ActiveUnit)
                        {
                            ForegroundColor = ConsoleColor.DarkRed;
                        }
                        else if (FoeRow[i] == TargetName && FoeRow[i] != "")
                        {
                            ForegroundColor = ConsoleColor.DarkRed;
                        }
                        else if (i == TargetID && TargetMode == 1)
                        {
                            ForegroundColor = ConsoleColor.DarkRed;
                        }

                        Write(FoeRow[i]);
                    }
                }
                else if (FoeRow.Count > i)
                {
                    GenerateBlankSpace(HUDLength - (FoeRow[i].Length));

                    if (FoeRow[i] == ActiveUnit)
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                    }
                    else if (FoeRow[i] == TargetName && FoeRow[i] != "")
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                    }
                    else if (i == TargetID && TargetMode == 1)
                    {
                        ForegroundColor = ConsoleColor.DarkRed;
                    }

                    Write(FoeRow[i]);
                }

                ForegroundColor = getColor();
                WriteLine("");
            }

            string Menu = "---------------------------------------------------------------------------------------------------------\n|    1. Attack    |    2. Special    |    3. Item    |    4. Defend    |    5. Check    |    6. Run     |\n---------------------------------------------------------------------------------------------------------\n";
            WriteLine($@"{Menu}");
        }

        private void GenerateBlankSpace(int spaces) //Used by DrawBattleHUD. Generates space between the player's side of the screen and the enemy's side.
        {
            for (int i = 0; i < spaces; i++)
            {
                Write(" ");
            }
        }

        private ConsoleColor GetHealthColor(int UnitHP, int UnitMaxHP, bool fainted = false) //Used by DrawBattleHUD. Helps determine what color should be used to indicate a player character's health bar.
        {
            ConsoleColor ReturnValue = ConsoleColor.Green;

            if (fainted)
            {
                ReturnValue = ConsoleColor.DarkRed;
            }
            else
            {
                float healthPercent = (float)UnitHP / (float)UnitMaxHP;

                if (healthPercent >= 0.75)
                {
                    ReturnValue = ConsoleColor.Green;
                }
                else if (healthPercent >= 0.33)
                {
                    ReturnValue = ConsoleColor.DarkYellow;
                }
                else
                {
                    ReturnValue = ConsoleColor.Red;
                }
            }

            return ReturnValue;
        }

        private void WriteBattleActionText(string Unit, ConsoleColor UnitColor, CharacterTextFormat Ending) //Used when building the message that tells the player what they're doing.
        {
            ForegroundColor = UnitColor;
            Game_PrintMessage(Unit, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" is going to: ", Ending, true, true);
        }
        
        private void WriteBattleActionText(string Unit, ConsoleColor UnitColor, string Action, ConsoleColor ActionColor, CharacterTextFormat Ending)
        {
            ForegroundColor = UnitColor;
            Game_PrintMessage(Unit, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" is going to ", RegularFormat, true, true);
            ForegroundColor = ActionColor;
            Game_PrintMessage(Action, Ending, true, true);
            ForegroundColor = getColor();
        }

        private void WriteBattleActionText(string Unit, ConsoleColor UnitColor, string Action, ConsoleColor ActionColor, string TargetName, ConsoleColor TargetColor, CharacterTextFormat Ending)
        {
            ForegroundColor = UnitColor;
            Game_PrintMessage(Unit, RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage(" is going to ", RegularFormat, true, true);
            ForegroundColor = ActionColor;
            Game_PrintMessage($"{Action} ", RegularFormat, true, true);
            ForegroundColor = TargetColor;
            Game_PrintMessage(TargetName, Ending, true, true);
            ForegroundColor = getColor();
        }

        private int GetPlayerSpeed() //Returns the total speed of the player's party.
        {
            int speed = protag.Speed;

            foreach(PartyMember member in protag.Allies)
            {
                speed += member.Speed;
            }

            return speed;
        }

        private int GetEnemySpeed(List<Enemy> EnemyList) //Returns the total speed of the enemy team.
        {
            int speed = 0;

            foreach(Enemy foe in EnemyList)
            {
                speed += foe.EnemySpeed;
            }

            return speed;
        }

        private int GetPartySize() //Returns the size of the player's party.
        {
            int i = 1;

            foreach (PartyMember member in protag.Allies)
            {
                i++;
            }

            return i;
        }

        private void GetEnemyCount(List<Enemy> EnemyList) //Changes the names of our identified enemies if there are multiple versions of the same enemy at once, to avoid confusion.
        {
            string[] ExtraIdentifiers = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };

            for (int i = 0; i < EnemyList.Count; i++)
            {
                int numFound = 0;
                string OriginalName = EnemyList[i].EnemyName;
                bool FoundMultiple = false;

                foreach (Enemy badguy in EnemyList)
                {
                    if (badguy.EnemyName == OriginalName)
                    {
                        if (numFound > 0)
                        {
                            FoundMultiple = true;
                            badguy.ChangeName(badguy.EnemyName + " " + ExtraIdentifiers[numFound]);
                        }

                        numFound++;
                    }
                }

                if (FoundMultiple)
                {
                    EnemyList[i].ChangeName(EnemyList[i].EnemyName + " " + ExtraIdentifiers[0]);
                }
            }
        }

        private void PlayBattleSound(string sound) //This is SUPPOSED to play sounds. TODO: Fix it
        {
            string SoundPath = Environment.CurrentDirectory + @"\SFX\";
            SoundPlayer SFXPlayer = new SoundPlayer()
            {
                
                SoundLocation = SoundPath + sound,
            };

            SFXPlayer.Load();
            SFXPlayer.Play();
        }

        private void PrintConfirmationMessage() //A function that prints the "Press ENTER to confirm" message.
        {
            Game_PrintMessage("Press ", RegularFormat, true, true);
            ForegroundColor = ConsoleColor.Yellow;
            Game_PrintMessage("ENTER ", RegularFormat, true, true);
            ForegroundColor = getColor();
            Game_PrintMessage("to confirm, or type a message to go back and select a different action. ", EndFormat, true, true);
        }

        private void PrintGenericIntro(List<Enemy> EnemyList) //Prints a generic battle intro message for unimportant fights.
        {
            string message = "You've encountered ";

            for (int i = 0; i < EnemyList.Count; i++)
            {
                if (EnemyList.Count == 1)
                {
                    message = message + EnemyList[i].EnemyName + "!";
                }
                else if (EnemyList.Count == 2)
                {
                    message = message + EnemyList[i].EnemyName + " and " + EnemyList[i + 1].EnemyName + "!";
                    i++;
                }
                else
                {
                    if (i + 1 < EnemyList.Count)
                    {
                        message = message + EnemyList[i].EnemyName + ", ";
                    }
                    else
                    {
                        message = message + "and " + EnemyList[i].EnemyName + "!";
                    }
                }
            }

            Game_PrintMessage(message, BattleText);
        }

        private void Game_PrintMessage(string dialogue, CharacterTextFormat NewSpeaker, bool SkipIt = false, bool DontClear = false) //Exactly the same as the Game class' method of the same name, with some new options.
        {
            ActiveMessage = new TextFunctions(dialogue, NewSpeaker, SkipIt, DontClear, 10);
            while (!ActiveMessage.FinishedPrinting)
            {
                //Wait until the current message stops printing before starting a new one, otherwise things get really weird.
            }
        }

        private void GameOver() //Game over. Happens when the protagonist faints, and allows the player to restart. If this were a full game, I'd work in a save/load feature, but since this is just a quick 5-10 minute single-battle game, this is fine.
        {
            BattleIsActive = false;

            ForegroundColor = ConsoleColor.DarkRed;
            CharacterTextFormat GameOverNarrator = new CharacterTextFormat("", ConsoleColor.White, ConsoleColor.Red, false, true, false, true, false, false);
            Game_PrintMessage("Game over...", GameOverNarrator, true);
            GameOverNarrator.TextColor = getColor();
            Game_PrintMessage("Would you like to Restart? [Y/N] ", GameOverNarrator, true, true);

            string response = ReadLine();

            if (ResponseIsConfirmation(response))
            {
                new Game("Richard McConnell", "Boss of Bosses", 180, 50, ConsoleColor.White);
            }
            else
            {
                Environment.Exit(0);
            }
        }
    }
}