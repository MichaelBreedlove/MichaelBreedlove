﻿using System.Collections.Generic;
using static System.Console;

namespace GameSpace
{
    public class Player
    {
        public string Name { get; private set; } = "";

        public int CurrentHealth { get; private set; } = 0;
        public int MaxHealth { get; private set; } = 0;
        public int Speed { get; private set; } = 0;
        public int Strength { get; private set; } = 0;
        public int Defense { get; private set; } = 0;
        public int Luck { get; private set; } = 0;
        public int Intellect { get; private set; } = 0;
        public bool IsProtag { get; private set; } = false;
        public bool Battle_Defending { get; set; } = false;
        public bool Battle_PsyBarrier { get; set; } = false;
        public bool Battle_Charging { get; set; } = false;
        public bool Fainted = false;

        public Inventory PlayerInv = new Inventory();

        public List<PartyMember> Allies = new List<PartyMember>();
        public List<Ability> Skills = new List<Ability>();

        public Player(string GivenName, int BaseMaxHP, int BaseSpeed, int str, int def, int luck, int intel)
        {
            Name = GivenName;
            MaxHealth = BaseMaxHP;
            CurrentHealth = MaxHealth;
            Speed = BaseSpeed;
            Strength = str;
            Defense = def;
            Luck = luck;
            Intellect = intel;
            IsProtag = true;
        }

        virtual public void ChangeName(string NewName)
        {
            Name = NewName;
        }

        virtual public void ChangeHP(int HPMod)
        {
            CurrentHealth += HPMod;
            if (CurrentHealth < 0)
            {
                CurrentHealth = 0;
            }
            else if (CurrentHealth > MaxHealth)
            {
                CurrentHealth = MaxHealth;
            }
        }

        virtual public void ShowAbilities()
        {
            int NumAbilities = 1;
            WriteLine("");

            foreach (Ability skill in Skills)
            {
                WriteLine($"{NumAbilities}. {skill.AbilityName}");
                NumAbilities++;
            }
        }
    }
}