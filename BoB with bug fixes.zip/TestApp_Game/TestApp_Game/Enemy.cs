﻿namespace GameSpace
{
    public class Enemy //Pretty self-explanatory, this class is used for our enemies.
    {
        public string EnemyName { get; private set; } = "Bad Guy";
        public int EnemyHP { get; private set; } = 300;
        public int EnemyMaxHP { get; private set; } = 300;
        public int EnemyStrength { get; private set; } = 8;
        public int EnemySpeed { get; private set; } = 4;
        public int EnemyIntellect { get; private set; } = 6;
        public int EnemyDefense { get; private set; } = 2;
        public bool Battle_MindBent { get; set; } = false;
        public bool Battle_Enraged { get; set; } = false;
        public int PoisonCounter { get; set; } = 0;
        public Player Battle_Enraged_Target { get; set; } = Game.protag;

        public Enemy(string Name, int HP, int MaxHP, int Strength, int Speed, int Intellect, int Defense)
        {
            EnemyName = Name;
            EnemyHP = HP;
            EnemyMaxHP = MaxHP;
            EnemyStrength = Strength;
            EnemySpeed = Speed;
            EnemyIntellect = Intellect;
            EnemyDefense = Defense;
        }

        public void ChangeName(string newName)
        {
            EnemyName = newName;
        }

        public void ChangeHP(int Adjustment)
        {
            EnemyHP += Adjustment;
        }
    }
}