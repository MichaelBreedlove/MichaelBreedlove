﻿using System;
using static System.Console;
using System.Timers;

namespace GameSpace
{
    public class TextFunctions
    {
        char[] MessageCharacters; //The messages, in the form of a char array.

        int CurrentChar = 0; //Our current position in the char array.

        public bool FinishedPrinting = false; //Is the message finished printing?

        bool SkipInput = false; //Should we ignore the player's input?

        bool DoNotClear = false; //Should we skip clearing the console?

        bool PlayerHasPressed = false; //Has the player pressed a button during the typing of this message?

        Timer PrintSlowly = new Timer(25); //Timer used to gradually print the message. Prints 1 character every 25 ms.

        int PrintInterval = 25;

        CharacterTextFormat Speaker; //The text format used by whoever is speaking this message.

        ConsoleColor DefaultColor; //The game window's default color. The foreground color will revert to this at the end of each message if a custom color is used.

        public TextFunctions(string dialogue, CharacterTextFormat NewSpeaker, bool SkipIt = false, bool DontClear = false, int Interval = 25) //Constructor. Sets our variables and begins the printing of the message.
        {
            MessageCharacters = dialogue.ToCharArray();
            Speaker = NewSpeaker;
            SkipInput = SkipIt;
            DoNotClear = DontClear;
            PrintSlowly.Enabled = false;
            PlayerHasPressed = false;
            CurrentChar = 0;
            PrintInterval = Interval;

            PrintMessage();
        }

        public void PrintMessage() //Begin printing.
        {
            if (!DoNotClear || Speaker.ClearAll) //Clear the console window, unless told not to.
            {
                Clear();
            }

            DefaultColor = Game.getColor(); //Set DefaultColor.

            if (Speaker.IsDialogue) //If the message is dialogue, print the speaker's name before anything else.
            {
                if (Speaker.UseNameColor)
                {
                    ForegroundColor = Speaker.NameColor;
                }
                else
                {
                    ForegroundColor = DefaultColor;
                }
                WriteLine($"{Speaker.DisplayName}:");

                if (Speaker.UseTextColor)
                {
                    ForegroundColor = Speaker.TextColor;
                }
                else
                {
                    ForegroundColor = DefaultColor;
                }

                Write("     ");
            }
            else //If the message is not dialogue, skip directly to the message.
            {
                if (Speaker.UseTextColor)
                {
                    ForegroundColor = Speaker.TextColor;
                }
            }

            PrintSlowly.Elapsed += PrintCharactersOverTime; //Adds the PrintCharactersOverTime method to our PrintSlowly timer.
            PrintSlowly.Enabled = true; //Enables PrintSlowly.
            PrintSlowly.AutoReset = true; //Automatically restart the PrintSlowly timer every time it reaches 0 ms.

            while (!PlayerHasPressed && Speaker.RequireInput && !SkipInput) //Detect key presses while the message is printing. Only works if we want the message to allow user inputs.
            {
                ReadKey(true);
                PlayerHasPressed = true;
            }
        }

        private void PrintCharactersOverTime(Object source, System.Timers.ElapsedEventArgs Args) //This timer is used to print messages one character at a time. It's completely cosmetic and unnecessary, but I thought it would be neat.
        {
            do //Prints the current char in our MessageCharacters array, then increments the position.
            {
                Write(MessageCharacters[CurrentChar]);

                //Pause for a brief moment on certain characters, giving the illusion of speech:
                if (MessageCharacters[CurrentChar] == '.' || MessageCharacters[CurrentChar] == '!' || MessageCharacters[CurrentChar] == '?')
                {
                    PrintSlowly.Interval = PrintInterval * 14;
                }
                else if (MessageCharacters[CurrentChar] == ',')
                {
                    PrintSlowly.Interval = PrintInterval * 6;
                }
                else
                {
                    PrintSlowly.Interval = PrintInterval;
                }

                CurrentChar++;
            }
            while (PlayerHasPressed && CurrentChar < MessageCharacters.Length); //If the player presses a button while the text is printing, automatically print the rest of the message instantly. Otherwise, continue to print one character at a time.

            if (CurrentChar >= MessageCharacters.Length) //When we reach the end of the message, stop the timer and perform end-message operations (such as reverting the foreground color, printing spacers, and taking key presses).
            {
                CurrentChar = 0;

                PrintSlowly.Enabled = false; //Disable PrintSlowly.
                PrintSlowly.Dispose(); //Dispose PrintSlowly.

                if (Speaker.Spacer) //If we need a spacer, print a spacer.
                {
                    WriteLine("");
                }

                ForegroundColor = DefaultColor; //Reset our foreground color.

                if (Speaker.RequireInput && !SkipInput && PlayerHasPressed) //If we need a key press, detect a key press.
                {
                    ReadKey(true);
                }

                FinishedPrinting = true; //Tell the program we are finished printing the message.
            }
        }

        internal static bool ResponseIsConfirmation(string response) //Checks a pre-determined list of words to check if the player's response to a query is some variation of "yes".
        {
            response = response.ToLower(); //Saves the programmer some time when adding items to the list of valid responses.

            string[] Valid_Responses = { "yes", "y", "ye", "yep", "yeah", "yea", "confirm", "do it", "sure", "alright", "correct", "yup" };

            bool confirmed = false;

            foreach (string item in Valid_Responses)
            {
                if (response == item)
                {
                    confirmed = true;
                    break; //Break if we find a match, so we don't keep going through the loop if we don't have to. Probably makes next to no difference, but optimization is always nice to have.
                }
            }

            return confirmed;
        }

        internal static string GetDialogueResponse() //Used mainly in cutscenes where the player gets to respond to something someone says.
        {
            Write("[Enter a Response]: ");
            return ReadLine().ToLower();
        }
    }

    public class CharacterTextFormat //Some characters have special dialogue settings. This class exists to be passed to PrintMessage, that way the coder doesn't need to repeat the same settings over and over.
    {
        public string DisplayName { get; } = "";
        public ConsoleColor NameColor { get; set; } = ConsoleColor.White;
        public ConsoleColor TextColor { get; set; } = ConsoleColor.White;
        public bool UseNameColor { get; } = false;
        public bool UseTextColor { get; } = false;

        public bool RequireInput { get; } = false;
        public bool Spacer { get; } = true;
        public bool IsDialogue { get; } = false;
        public bool ClearAll { get; } = false;

        public CharacterTextFormat(string name, ConsoleColor nameShade, ConsoleColor textShade, bool useName, bool useText, bool input, bool addSpace, bool dialogue, bool clear)
        {
            DisplayName = name;
            NameColor = nameShade;
            TextColor = textShade;
            UseNameColor = useName;
            UseTextColor = useText;
            RequireInput = input;
            Spacer = addSpace;
            IsDialogue = dialogue;
            ClearAll = clear;
        }
    }
}